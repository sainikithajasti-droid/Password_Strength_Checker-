# Password Strength Checker

A simple Python cybersecurity project for evaluating password strength using:

- Password policy checks
- Entropy estimation
- Common-password/leak-list checking
- Strength classification
- Actionable security feedback

## Requirements

- Python 3.9 or later
- No external libraries are required.

## How to run

Open a terminal inside this folder and run:

```bash
python password_strength_checker.py
```

On some systems use:

```bash
python3 password_strength_checker.py
```

Use **test passwords only** for demonstration. Do not paste your real password into a project, screenshot, GitHub repository, or chat.

## Entropy formula

The project estimates entropy using:

`Entropy = password_length × log2(character_set_size)`

The character set includes lowercase letters, uppercase letters, digits, and symbols that occur in the password.

This is an estimate, not a guarantee of real-world security. Human-chosen passwords can have much less effective entropy because they are predictable.

## Strength levels

- Weak: common/leaked password, failed policy, or low estimated entropy
- Moderate: policy is met and estimated entropy is at least 50 bits
- Strong: estimated entropy is at least 70 bits
- Exceptional: estimated entropy is at least 90 bits

## Project files

```text
password_strength_checker/
├── password_strength_checker.py
├── common_passwords.txt
├── README.md
└── sample_output.txt
```

## Security notes

This demo never saves the password to a file and uses `getpass` so the password is not displayed while typing.

The local common-password list is only a demonstration. A production system should use a trusted breach-password service or a properly handled password-compromise dataset. Passwords should never be sent to an external service in plaintext.

## Example test passwords

Use examples such as:

- `password123`
- `Study@2026!Secure`
- `River!Cloud#91Moon`
