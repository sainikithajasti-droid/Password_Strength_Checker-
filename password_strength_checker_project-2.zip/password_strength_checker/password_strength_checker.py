import math
import re
import getpass
from pathlib import Path

COMMON_PASSWORDS = {
    "password", "password123", "123456", "12345678", "123456789",
    "qwerty", "qwerty123", "admin", "admin123", "welcome",
    "letmein", "iloveyou", "abc123", "111111", "000000",
    "1234567890", "passw0rd", "football", "monkey", "dragon"
}

def load_common_passwords():
    """Load extra common passwords from common_passwords.txt if available."""
    path = Path(__file__).with_name("common_passwords.txt")
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            word = line.strip().lower()
            if word and not word.startswith("#"):
                COMMON_PASSWORDS.add(word)

def calculate_entropy(password):
    """Estimate entropy from password length and character-set size."""
    charset = 0
    if re.search(r"[a-z]", password):
        charset += 26
    if re.search(r"[A-Z]", password):
        charset += 26
    if re.search(r"\d", password):
        charset += 10
    if re.search(r"[^A-Za-z0-9]", password):
        charset += 33  # Approx. printable ASCII symbols

    if charset == 0:
        return 0.0

    return len(password) * math.log2(charset)

def policy_checks(password):
    return {
        "Minimum length (12)": len(password) >= 12,
        "Lowercase letter": bool(re.search(r"[a-z]", password)),
        "Uppercase letter": bool(re.search(r"[A-Z]", password)),
        "Digit": bool(re.search(r"\d", password)),
        "Special character": bool(re.search(r"[^A-Za-z0-9]", password)),
    }

def classify_strength(entropy, policy_ok, leaked):
    if leaked:
        return "Weak"
    if not policy_ok or entropy < 50:
        return "Weak"
    if entropy < 70:
        return "Moderate"
    if entropy < 90:
        return "Strong"
    return "Exceptional"

def feedback(password, checks, leaked):
    tips = []

    if len(password) < 12:
        tips.append("Use at least 12 characters.")
    if not checks["Uppercase letter"]:
        tips.append("Add at least one uppercase letter (A-Z).")
    if not checks["Lowercase letter"]:
        tips.append("Add at least one lowercase letter (a-z).")
    if not checks["Digit"]:
        tips.append("Add at least one number (0-9).")
    if not checks["Special character"]:
        tips.append("Add at least one special character, such as ! @ # $.")
    if leaked:
        tips.append("This password appears in the local common-password list. Choose a unique password.")
    if not tips:
        tips.append("Good policy compliance. Prefer a long, unique passphrase and never reuse it.")

    return tips

def check_password(password):
    load_common_passwords()
    checks = policy_checks(password)
    entropy = calculate_entropy(password)
    leaked = password.lower() in COMMON_PASSWORDS
    policy_ok = all(checks.values())
    strength = classify_strength(entropy, policy_ok, leaked)

    return {
        "length": len(password),
        "entropy": entropy,
        "checks": checks,
        "policy_ok": policy_ok,
        "common_password": leaked,
        "strength": strength,
        "feedback": feedback(password, checks, leaked),
    }

def print_report(result):
    print("\n" + "=" * 55)
    print("           PASSWORD STRENGTH CHECKER")
    print("=" * 55)
    print(f"Length       : {result['length']}")
    print(f"Entropy      : {result['entropy']:.2f} bits")
    print(f"Policy       : {'PASS' if result['policy_ok'] else 'FAIL'}")
    print(f"Common leak  : {'YES' if result['common_password'] else 'NO'}")
    print(f"Strength     : {result['strength']}")
    print("\nPolicy checks:")
    for name, passed in result["checks"].items():
        print(f"  [{'✓' if passed else '✗'}] {name}")

    print("\nActionable feedback:")
    for tip in result["feedback"]:
        print(f"  - {tip}")
    print("=" * 55)

def main():
    print("Password Strength Checker")
    print("Tip: Do not use a real password while demonstrating this project.")
    password = getpass.getpass("Enter a test password: ")

    if not password:
        print("Password cannot be empty.")
        return

    result = check_password(password)
    print_report(result)

if __name__ == "__main__":
    main()
